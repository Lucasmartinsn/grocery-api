/*
default user, for login
cpf:88888888888
password:123456
*/

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE t_customer (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    contact int,
    cpf BIGINT UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE TABLE t_address (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    customer_id UUID REFERENCES t_customer(id) ON DELETE CASCADE,
    street VARCHAR(255) NOT NULL,
    block VARCHAR(255),
    number INT NOT NULL,
    state VARCHAR(255) NOT NULL
);

CREATE TABLE t_credit_card (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    customer_id UUID REFERENCES t_customer(id) ON DELETE CASCADE,
    number BIGINT UNIQUE NOT NULL,
    csv INT NOT NULL,
    name_card VARCHAR(255) NOT NULL,
    validity VARCHAR(10) NOT NULL
);

CREATE TABLE t_employee (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    cpf BIGINT UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    office VARCHAR(255),
    active BOOLEAN NOT NULL,
    admin BOOLEAN NOT NULL,
    creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE TABLE t_supplier (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    cnpj BIGINT UNIQUE NOT NULL,
    contract_number BIGINT UNIQUE NOT NULL,
    company_name VARCHAR(255) NOT NULL,
    status BOOLEAN NOT NULL
);

CREATE TABLE t_batch (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    supplier_id UUID REFERENCES t_supplier(id) ON DELETE CASCADE,
    volume INT NOT NULL,
    price FLOAT8 NOT NULL,
    purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    delivery_date TIMESTAMP NOT NULL
);

CREATE TABLE t_product (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    batch_id UUID REFERENCES t_batch(id) ON DELETE SET NULL,
    supplier_id UUID REFERENCES t_supplier(id),
    name VARCHAR(255) NOT NULL,
    volume INT NOT NULL,
    unit_price FLOAT8 NOT NULL,
    validity TIMESTAMP NOT NULL
);

insert into t_customer (name, email, contact, cpf, password) 
values ('user teste', 'teste.user@gamil.com',0000000000,88888888888,'$2a$10$5295Rv1MsuwuS7pSYDy5n.CqTskTo6w8ISft6a9Ia0RosrMU.3p3.')